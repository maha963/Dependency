package com.example.mylibrary;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class ToastHelper {

    public void display(){

        Log.d("tag","hello");
    }
}
